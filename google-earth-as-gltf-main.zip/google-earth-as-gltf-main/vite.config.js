export default {
  base: './'
}